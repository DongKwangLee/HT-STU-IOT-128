#define trigger PORTC.0

#define echo PINC.1

void return_menu(void);


unsigned int getEcho(void)
{
    unsigned int range;

	DDRC=0x0F; trigger=1; delay_us(10); trigger=0; DDRC=0xF0;
    while(!echo); TCNT1=0; TCCR1B=2;
    while(echo); TCCR1B=8; range=TCNT1/116;
    return(range);
}    

//LCD ���
void LCD_usonic(int dis_data)
{
    unsigned char Decimal[4];

    Decimal[2]='0'+dis_data/100;
    dis_data=dis_data%100;
    Decimal[1]='0'+dis_data/10;
    dis_data=dis_data%10;
    Decimal[0]='0'+dis_data;

    LCD_pos(0,1);
    LCD_data(Decimal[2]);
    LCD_data('m');
    LCD_data(Decimal[1]);
    LCD_data(Decimal[0]);
    LCD_str("cm");
}

void ultrasonic_test(void)
{
    unsigned int range;
    
    TCCR1A=0;
    TCCR1B=8;     
    
    LCD_CLEAR();
    LCD_pos(0,0);
    LCD_str("6.U_sonic(PC0-1)");  
      
    while(1)
    {   
        range=getEcho();
        LCD_usonic(range);
        
        return_menu();
    }   
}