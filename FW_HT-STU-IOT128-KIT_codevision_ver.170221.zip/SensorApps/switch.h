void return_menu(void);


void sw_test(void)
{
    PORTC.4=1;PORTC.5=1;PORTC.6=1;PORTC.7=1;
    DDRC.4=0;DDRC.5=0;DDRC.6=0;DDRC.7=0;
    
    LCD_CLEAR();
    
    LCD_pos(0,0);
    LCD_str("8.Switch(PC4-7)");
    LCD_pos(0,1);
    LCD_str("S1: S2: S3: S4: ");
    
    while(1)
    {
        if(!(PINC.4))  {LCD_pos(3,1);  LCD_str("O");}
        else           {LCD_pos(3,1);  LCD_str("-");}
        if(!(PINC.5))  {LCD_pos(7,1);  LCD_str("O");}
        else           {LCD_pos(7,1);  LCD_str("-");}
        if(!(PINC.6))  {LCD_pos(11,1); LCD_str("O");}
        else           {LCD_pos(11,1); LCD_str("-");}    
        if(!(PINC.7))  {LCD_pos(15,1); LCD_str("O");}
        else           {LCD_pos(15,1); LCD_str("-");}   
    
        delay_ms(100);
    
        return_menu();
    }
}