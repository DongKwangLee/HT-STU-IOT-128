void return_menu(void);

void cds_test(void)
{
    LCD_CLEAR();
    
    LCD_pos(0,0);
    LCD_str("5.CDS(ADC7)");
    LCD_pos(0,1);
    LCD_str("ADC:");
    
    while(1)
    {
        LCD_pos(4,1);
        LCD_decimal(Read_Adc_Data(7));
        delay_ms(100);
    
        return_menu();
    }
}
