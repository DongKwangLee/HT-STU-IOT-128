

int step_now=0;    
int STEP_DELAY= 10;

void return_menu(void);

void stepmotor_init(void)
{
    //setting
    DDRB.0=1;DDRB.1=1;DDRB.2=1;DDRB.3=1;
    //init
    PORTB.0=0;PORTB.1=0;PORTB.2=0;PORTB.3=0; 
}


void step_go(void)
{
    switch(step_now)
    {
        case 0 :
            PORTB.0=1;
            PORTB.1=0;
            PORTB.2=0;
            PORTB.3=0;
            step_now=1;
            break;
        case 1 :
            PORTB.0=0;
            PORTB.1=0;
            PORTB.2=1;
            PORTB.3=0;
            step_now=2;
            break;
        case 2 :
            PORTB.0=0;
            PORTB.1=1;
            PORTB.2=0;
            PORTB.3=0;
            step_now=3;
            break;
        case 3 :
            PORTB.0=0;
            PORTB.1=0;
            PORTB.2=0;
            PORTB.3=1;
            step_now=0;
            break;
         default :  break;
    }
    delay_ms(STEP_DELAY);    
}

void step_back(void)
{
    switch(step_now)
    {
        case 0 :
            PORTB.0=0;
            PORTB.1=0;
            PORTB.2=0;
            PORTB.3=1;
            step_now=3;
            break;
        case 1 :
            PORTB.0=1;
            PORTB.1=0;
            PORTB.2=0;
            PORTB.3=0;
            step_now=0;
            break;
        case 2 :
            PORTB.0=0;
            PORTB.1=0;
            PORTB.2=1;
            PORTB.3=0;
            step_now=1;
            break;
        case 3 :
            PORTB.0=0;
            PORTB.1=1;
            PORTB.2=0;
            PORTB.3=0;
            step_now=2;
            break;
        default :  break;
    }
    delay_ms(STEP_DELAY);    
}


void stepmotor_test(void)
{
    
    stepmotor_init();
    
    LCD_CLEAR();
    
    LCD_pos(0,0);
    LCD_str("10.STEP M. TEST");
    LCD_pos(0,1);
    LCD_str("0:<-     ms 3:->");
    
    while(1)
    {
        if(PIND.0 == 0)        {step_go();}        //1
        else if(PIND.3 == 0)   {step_back();}        //4
        else if(PIND.1==0)
        {
            if(STEP_DELAY<=1)   {STEP_DELAY=1;}
            else                {STEP_DELAY--;}
        }
        else if(PIND.2==0)
        {
            if(STEP_DELAY>=1000)    {STEP_DELAY=1000;}
            else                    {STEP_DELAY++;}
        }         
        
        LCD_pos(5,1);
        LCD_decimal(STEP_DELAY);
       
        return_menu();
    }    
}