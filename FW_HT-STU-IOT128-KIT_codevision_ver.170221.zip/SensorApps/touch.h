void return_menu(void);


void touch_test(void)
{
    PORTC.3=1;
    DDRC.3=0;
    
    LCD_CLEAR();
    
    LCD_pos(0,0);
    LCD_str("7.Touch((PC3)");
    
    while(1)
    {
        if(PINC.3)
        {
            LCD_pos(0,1);
            LCD_str("Touch O N");
        }
        else
        {
            LCD_pos(0,1);
            LCD_str("Touch OFF");   
        }
        delay_ms(100);
    
        return_menu();
    }
}