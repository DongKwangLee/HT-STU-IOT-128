void return_menu(void);

void accel_test(void)
{
    LCD_CLEAR();
    
    LCD_pos(0,0);
    LCD_str("4.Accel");
        
    LCD_pos(0,1);
    LCD_str("X:");
    LCD_pos(8,1);
    LCD_str("Y:");
    LCD_pos(8,0);
    LCD_str("Z:");
    while(1)
    {
       LCD_pos(2,1);
       LCD_decimal(Read_Adc_Data(7)); //X
       LCD_pos(10,1);
       LCD_decimal(Read_Adc_Data(6)); //Y
       LCD_pos(10,0);
       LCD_decimal(Read_Adc_Data(5)); //Z
  
       delay_ms(100);
    
       return_menu();
    }
}