void return_menu(void);


void fsr_test(void)
{
    LCD_CLEAR();
    
    LCD_pos(0,0);
    LCD_str("1.FSR(ADC1)");
    LCD_pos(0,1);
    LCD_str("ADC:");
    
    while(1)
    {
        LCD_pos(4,1);
        LCD_decimal(Read_Adc_Data(1));
        delay_ms(100);
    
        return_menu();
    }
}