#define MAX_MENU 11

int menu_cnt=0;


void menu_lcd(void)
{
    LCD_pos(0,1);     
    LCD_str("                ");
    LCD_pos(0,1);
    switch(menu_cnt)
        {
        case 1 : LCD_str("1.FSR TEST"); break;
        case 2 : LCD_str("2.PSD TEST"); break;
        case 3 : LCD_str("3.Joystick TEST"); break;  
        case 4 : LCD_str("4.Accel TEST"); break;
        case 5 : LCD_str("5.CDS TEST"); break;
        case 6 : LCD_str("6.U_sonic TEST"); break;
        case 7 : LCD_str("7.Touch TEST"); break;
        case 8 : LCD_str("8.Switch TEST"); break;
        case 9 : LCD_str("9.DC Motor TEST"); break;
        case 10 : LCD_str("10.STEP M. TEST"); break;
        case 11 : LCD_str("11.GLCD TEST"); break;

        default : break;
        }
}

void state_function(void)
{
    
    LCD_CLEAR();
    LCD_pos(0,0);
    LCD_str("*HT-STU-IOT-128*");
    LCD_pos(0,1);
    LCD_str("<-SELECT MENU->");
        
    while(1)
    {
        if(PIND.0 == 0)         //Btn <-
        {
            if(menu_cnt<=1) {menu_cnt=1;}
            else    {menu_cnt--;}
            menu_lcd();

        }     
        else if(PIND.2 == 0)    //Btn ->
        {
            if(menu_cnt>=MAX_MENU) {menu_cnt=MAX_MENU;}
            else {menu_cnt++;}
            menu_lcd();
        }    
        else if(PIND.1 == 0)    //Btn O
        {
            switch(menu_cnt)
            {
                case 1 : fsr_test(); break;
                case 2 : psd_test(); break;
                case 3 : joy_test(); break;
                case 4 : accel_test(); break; 
                case 5 : cds_test(); break;
                case 6 : ultrasonic_test(); break;
                case 7 : touch_test(); break;
                case 8 : sw_test(); break;
                case 9 : dcmotor_test(); break;
                case 10 : stepmotor_test(); break;
                case 11 : glcd_info(); break; 

                default : break;
            }   
        }
        else if(PIND.6 == 0)  // GLCD MODE
        {
            glcd_test();       
        }
                      
        delay_ms(200);
       
            
     }
}                    

void return_menu(void)
{
    if(PIND.7 == 0)
    {
        state_function();
    }
}