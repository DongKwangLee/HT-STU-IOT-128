void return_menu(void);

void joy_test(void)
{
    PORTC.2=1;
    DDRC.2=0;
    
    LCD_CLEAR();
    
    LCD_pos(0,0);
    LCD_str("3.Joystic");
    
    LCD_pos(0,1);
    LCD_str("X:");
    LCD_pos(7,1);
    LCD_str("Y:");
    
    
    while(1)
    {
        LCD_pos(2,1);
        LCD_decimal(Read_Adc_Data(3));
        LCD_pos(9,1);
        LCD_decimal(Read_Adc_Data(4));
        if(!(PINC.2))
        {
            LCD_pos(10,0);
            LCD_str("O N");
        }
        else
        {
            LCD_pos(10,0);
            LCD_str("OFF");   
        }
        delay_ms(100);   
    
        return_menu();
    }
}