#include <math.h>

void return_menu(void);


void psd_test(void)
{
    int adc;
    float volt;
    int distance;
        
    LCD_CLEAR();
    
    LCD_pos(0,0);
    LCD_str("2.PSD(ADC2)");
    LCD_pos(0,1);
    LCD_str("ADC:");
    
    LCD_pos(13,1);    
    LCD_str("cm");
    
    while(1)
    {
        adc=Read_Adc_Data(2);
        volt=adc*0.0048828125;   // 5V / 1024Sampling 
        distance=13*pow(volt,-1);  //���� Ư���� �ݿ�  
    
    
        LCD_pos(4,1);
        LCD_decimal(adc);
    
        LCD_pos(9,1);
        LCD_decimal(distance);
        
        delay_ms(100);
    
        return_menu();
    }
}