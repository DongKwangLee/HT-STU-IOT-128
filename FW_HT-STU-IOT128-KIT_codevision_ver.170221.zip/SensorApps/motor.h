void return_menu(void);


void motor_init(void)
{
    //setting
    DDRE.4=1; //PWM OUT
    DDRE.5=1; DDRE.6=1; // Direction OUT
    //init
    PORTE.4=0; // SPEED 0
    PORTE.5=1; PORTE.6=1; //STOP
}

void dcmotor_stop(void)
{
    PORTE.5=0;
    PORTE.6=0;
}

void dcmotor_go(void)
{
    PORTE.5=1;
    PORTE.6=0;
}

void dcmotor_back(void)
{
    PORTE.5=0;
    PORTE.6=1;
}


void dcmotor_test(void)
{
    motor_init();

    LCD_CLEAR();
    
    LCD_pos(0,0);
    LCD_str("MOTOR TEST");
    LCD_pos(0,1);
    LCD_str("0:<- 1:- 2:->");
    
    while(1)
    {
        if(PIND.0 == 0)        {dcmotor_go();}        //1
        else if(PIND.1 == 0)   {dcmotor_stop();}        //2
        else if(PIND.2 == 0)   {dcmotor_back();}        //3 
        
        return_menu();

    
    }

}