#define BIT(x)        (1 << (x))
#define SETBIT(x, y)    (x |= y)        
#define CLEARBIT(x, y)    (x &= ~y)

#define LCD_CLEAR()     LCD_pos(0,0);   LCD_str("                ");    LCD_pos(0,1);   LCD_str("                ")
#define LCD_EN          0
#define LCD_RS          2
#define LCD_RW          1
#define LCD_Cont_Port   PORTG    
#define LCD_PORT        PORTA

#define F_CPU  14745600                     // 7.3728 MHz clock

#define K_DELAY_100us    F_CPU/61349
#define K_DELAY_1ms    F_CPU/6013
#define K_DELAY_10ms    F_CPU/600   

void Delay_100us(unsigned char t) 
{
    unsigned int i;
    if (t==0) return;
    while (t--) for(i=0;i<K_DELAY_100us; i++);
}
  
void EN_L()    {    LCD_Cont_Port   = LCD_Cont_Port & ~BIT(LCD_EN);}
void EN_H()     {    LCD_Cont_Port  = LCD_Cont_Port | BIT(LCD_EN);}

void RS_L()    {    LCD_Cont_Port   = LCD_Cont_Port & ~BIT(LCD_RS);}
void RS_H()     {    LCD_Cont_Port  = LCD_Cont_Port | BIT(LCD_RS);}

void RW_L()    {    LCD_Cont_Port   = LCD_Cont_Port & ~BIT(LCD_RW);}

void LCD_clr(void)     // LCD �޸� Ŭ����
{                                        
    EN_H(); RW_L(); RS_L();    
    Delay_100us(2);    LCD_PORT=0x01;    Delay_100us(2);    
    RW_L(); RS_L();    EN_L();
}

void LCD_data(int dat)    // LCD ������ ����
{                
    EN_H(); RW_L(); RS_H();
    Delay_100us(2); 
    LCD_PORT=dat; 
    Delay_100us(2); 
    RW_L(); RS_H();    EN_L();
}
void LCD_str(flash unsigned char *str)    // LCD ������ ����(���ڿ�)
{   int i; 
    for(i=0;str[i]!=0;i++) 
    LCD_data(str[i]); 
}
void LCD_pos(unsigned char x, unsigned char y)     // LCD ������ ����  �ּҼ���
{
    EN_H(); RW_L(); RS_L();
    Delay_100us(2); 
    LCD_PORT=0x80|(x+y*0x40);    
    Delay_100us(2); 
    RW_L(); RS_L();    EN_L();
}

void LCD_putchdecu(unsigned char x, unsigned char y,unsigned int dt)	// unsigned int �� 0~62536���� ǥ�� ������ .
{
	unsigned int tmp;						
	tmp = dt;
    
    LCD_pos(x,y);
    
    LCD_data(TABLE[tmp/10000]);
    tmp %= 10000;
	LCD_data(TABLE[tmp/1000]);
	tmp %= 1000;
	LCD_data(TABLE[tmp/100]);
	tmp %= 100;
	LCD_data(TABLE[tmp/10]);
	LCD_data(TABLE[tmp%10]);
}

void LCD_decimal(int dec)
{
    unsigned char Decimal[4];

    Decimal[3]='0'+dec/1000;
    dec=dec%1000;
    Decimal[2]='0'+dec/100;
    dec=dec%100;
    Decimal[1]='0'+dec/10;
    dec=dec%10;
    Decimal[0]='0'+dec;
    
    LCD_data(Decimal[3]);
    LCD_data(Decimal[2]);
    LCD_data(Decimal[1]);
    LCD_data(Decimal[0]);
}