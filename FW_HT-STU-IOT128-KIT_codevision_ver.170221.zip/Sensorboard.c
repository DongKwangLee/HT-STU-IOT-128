#include "/Headers/mega128.h"
#include "/Headers/DELAY.h"
//--------------------------------
#include "/Headers/main.h"
//--------------------------------
#include "/Headers/clcd.h"
#include "/Headers/buzzer.h"
#include "/Headers/adc.h"
#include "/Headers/init.h"
//---------------------------------
#include "/SensorApps/Ultrasonic.h"
#include "/SensorApps/fsr.h"
#include "/SensorApps/joystic.h"
#include "/SensorApps/psd.h"
#include "/SensorApps/accel.h"
#include "/SensorApps/touch.h"
#include "/SensorApps/cds.h"
#include "/SensorApps/switch.h"
#include "/SensorApps/dcmotor.h"
#include "/SensorApps/stepmotor.h"
#include "/SensorApps/glcd.h"
#include "/SensorApps/state_function.h"


//--------------------

void main(void)
{
  
    delay_ms(50);
    init_devices();
    LCD_CLEAR();
    delay_ms(50);
    
 
          
    while(1)
    {  
         state_function();       
    }
  
}

